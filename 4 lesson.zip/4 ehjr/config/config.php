<?php

    define("ROOT", dirname(__DIR__));
    const CONFIG = ROOT . '/config';

    const HELPERS = ROOT . '/helpers';
