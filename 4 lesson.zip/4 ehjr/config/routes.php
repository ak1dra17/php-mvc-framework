<?php

/** @var \PHPFramework\Application $app */

use App\Controllers\HomeController;

$app->router->add('/', function (){
        return 'Приветик, МИР! / Hello, World!';
    }, ['GET', 'post']);

    $app->router->get('/test', [HomeController::class, 'test']);
    //$app->router->post('/test2/', [HomeController::class, 'test2']);
    $app->router->post('/contact/', [\App\Controllers\HomeController::class, 'contact']);

   
    $app->router->get('/post/(?P<slug>[a-z0-9-]+)/?', function () {
    return '<p>Some post</p>';
});

// dump($app->router->getRoutes());